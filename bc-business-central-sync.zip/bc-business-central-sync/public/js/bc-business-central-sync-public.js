/**
 * Public JavaScript for Business Central Sync.
 *
 * @package    BC_Business_Central_Sync
 * @subpackage BC_Business_Central_Sync/public
 */

// Public-facing JavaScript can be added here if needed
